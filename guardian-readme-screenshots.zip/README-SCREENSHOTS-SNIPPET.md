## 📸 Screenshots

### Extension popup

![Guardian Security extension popup](docs/screenshots/popup.png)

### Suspicious website warning

![Guardian Security suspicious website warning page](docs/screenshots/blocked-warning.png)

### Google search regression test

In v1.0.1, security-related search terms no longer cause Google itself to be blocked.

![Guardian Security Google search test](docs/screenshots/google-search-v1.0.1.png)
